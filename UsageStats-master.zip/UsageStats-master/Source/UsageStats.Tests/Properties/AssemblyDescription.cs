﻿using System.Reflection;

[assembly: AssemblyTitle("Application Usage Statistics unit tests")]
[assembly: AssemblyDescription("This library contains unit tests.")]
