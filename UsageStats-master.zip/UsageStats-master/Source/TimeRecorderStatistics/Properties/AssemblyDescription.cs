﻿using System.Reflection;
using System.Windows;

[assembly: AssemblyTitle("Time Recorder Statistics")]
[assembly: AssemblyDescription("This application shows statistics from the Time Recorder.")]

[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]