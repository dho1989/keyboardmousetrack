﻿using System.Reflection;

[assembly: AssemblyTitle("Time Recorder")]
[assembly: AssemblyDescription("Records usage statistics for your computer.")]