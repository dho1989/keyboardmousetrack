﻿using System.Reflection;
using System.Windows;

[assembly: AssemblyTitle("Application Usage Statistics")]
[assembly: AssemblyDescription("This application generates statistics on the usage of keyboard and mouse.")]

[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]