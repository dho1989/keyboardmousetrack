Application Usage Statistics
========================================================================
This project contains two applications:
- UsageStats: generates detailed statistics on the usage of keyboard and mouse.
- TimeRecorder: records the title of the active window every minute when the computer is in active use


Build requirements
- Microsoft .NET 4.5.2
- Visual Studio 2015


[![Build status](https://ci.appveyor.com/api/projects/status/78l59q8r5h1a6e21?svg=true)](https://ci.appveyor.com/project/objorke/usagestats)
